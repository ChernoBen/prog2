#include <iostream>
#include <string>
#include <cstring>
#include<stdlib.h>
#include<string.h>

using namespace std;
/*
 2) Escreva um programa que leia uyma string e gere outra com o conteudo da primeira invertido
*/




int main() {
  
  string frase;
  cin >> frase;
  cout << endl;
  cout << frase.length();




}